#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm> //para usar std::sort -> O(nlogn)
#include <list>

double maximo(std::list<int> & l, bool sorted = false){
	double max = 0;

	for(auto it = l.begin(); it != l.end() ; it++){
		if(max < *it)
			max = *it;
	}

	return max;
}

double media(std::list<int> & l){
	double aux = 0;
	for(auto it = l.begin(); it != l.end() ; it++){
		aux += *it;
	}
	return aux /= l.size();
} 

double mediana(std::list<int> & l,bool sorted = false){
	double aux = 0;
	size_t i = 0;
	size_t mid = l.size() / 2;
	auto it = l.begin();

	if(!sorted)
		l.sort();//O(nlog)
	for(i = 0; i != mid ; ++it , i++);

	if(l.size() % 2)
		return *it;


	else aux = (double) (( *it + *(it++) )/2);

	return aux;
}

double desviacion(std::list<int> & l){
	double aux = 0;
	double med = media(l);

	for(auto it = l.begin(); it != l.end() ; ++it ){
		aux += pow((*it - med), 2);
	}
	aux = sqrt(aux/(l.size()-1));

	return aux;
}


std::vector<double> moda(std::list<int> & l,bool sorted = false){//O(nlogn) peor caso, O(n) mejor caso, caso promedio depende de lo que tarda sort que segun std es O(nlogn)
    std::vector<double> output;
    double previous = NAN;
    size_t count, count_max;
    auto it = l.begin();
    if(!sorted)
    	l.sort();

    for(it = l.begin(), count = 0, count_max = 0; it != l.end() ; ++it){

        if(previous != *it){
            count = 1;
        } else {
            count++;
        }

        if (count > count_max){
            output.clear();
            output.push_back(*it);
            count_max = count;
        }
        else if (count == count_max){
            output.push_back(*it);
        }
        previous = *it;
    }

    if(output.size() == l.size())
        output.clear();
    
    return output;
}//espacial O(n)

void _variaciones(std::vector<int> & v,const size_t & indice, std::vector<double> * set, std::vector< std::vector<double> > * result){
    if(indice == v.size())
    	return;

    result->push_back(*set);
    
    for(size_t i = indice + 1 ; i < v.size(); i++){
    	set->push_back(v[i]);
    	_variaciones(v,i,set,result);
    	if(set->size())
    		set->erase(set->end()-1);
    }
    return;
}

std::vector< std::vector<double> > variaciones(std::list<int> & l){
    std::vector< std::vector<double> > * result = new std::vector< std::vector<double> >;
    std::vector<double> * aux = new std::vector<double>;
    std::vector<int> v;

    for(auto it = l.begin(); it != l.end() ; ++it)
    	v.push_back(*it);

    _variaciones(v,-1,aux,result);
 	return *result;
}

std::vector< std::vector<double> > permutaciones(std::list<int> & l){
	std::vector< std::vector<double> > output;
    std::vector<double> set;
    size_t n = l.size();
    std::vector<int> v;

    for(auto it = l.begin(); it != l.end() ; ++it)
    	v.push_back(*it);

    if(n > 8)//para mas de 8 elementos tarda mucho
    	n = 4;

	sort(v.begin(),v.end());//O(nlogn)

	do{//O(n!)
		for(size_t i = 0; i < n; i++)//O(n)
			set.push_back(v[i]);

		output.push_back(set);
		set.clear();
	}
	while( std::next_permutation(v.begin(), v.end()) );

	return output; //O(n!)
}//espacial O(n)

std::vector< std::vector<double> > variaciones_duplicados(std::list<int> & l){
	std::vector< std::vector<double> > output;
    std::vector<double> set;
    size_t n = l.size();
	size_t i = 0;    
    std::vector<int> v;

    for(auto it = l.begin(); it != l.end() ; ++it)
    	v.push_back(*it);

    if(v.size() > 8)//para mas de 8 elementos tarda mucho
    	n = 4;

	sort(v.begin(),v.end());

	for(size_t j = n; j != 0; j--){//O(n-1)
		do{		
			for(i = 0; i < j; i++)
				set.push_back(v[i]);
			if (j == 1)
				std::next_permutation(v.begin(),v.end());
			output.push_back(set);
			set.clear();
		}
		while ( std::next_permutation(v.begin(),v.end()) );//O(n!)
	}

	output.push_back(set);
	
	return output;//O(n!) * O (n) = O(n*n!)
}//espacial O(n)

