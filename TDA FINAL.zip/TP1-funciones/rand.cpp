#include <iostream>
#include <vector>
#include <cstdlib>
#include <fstream>
#include <ios>

int main(int argc,char * argv[]){
	std::fstream file;
	std::vector<int> v;
	int x = 0;
	char * ch;
	int max = strtod(argv[1],&ch);

	for(size_t i = 0; i < max; i++){
		v.push_back(rand() % 20);
	}

	file.open("numeros.txt", std::ios::trunc | std::ios::out);

	for(auto each : v)
		file << each << std::endl;

	return 0;
}