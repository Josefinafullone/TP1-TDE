#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <ios>
#include <cmath>
#include <ctime>
#include "vector.hpp"

#define MAYOR [](int v1, int v2){return v1 > v2;}
#define MAX_FUNCTIONS 8
static int func = 20;
static std::string dict[MAX_FUNCTIONS] = { "maximo",
									  "media",
							   		  "mediana",
									  "moda",
									  "permutaciones",
									  "desviacion",
									  "variaciones",
									  "variaciones_duplicados"
};

void validate_arguments(int & argc,char * argv[]){
	size_t i = 0, j = 0;
	if(argc != 3){
		std::cerr << "Error number of arguments" << std::endl;
		exit(1);
	}
	for(i = 0, j = 0; i < MAX_FUNCTIONS; i++){
		if(argv[2] == dict[i])
			func = i;
		if(argv[2] != dict[i])
			j++;
	}
	if(j == MAX_FUNCTIONS){
		std::cerr << "Error function does not exist" << std::endl;
		exit(1);
	}

	return;
}

int main(int argc, char* argv[]){
	std::fstream input_file, output_file, time_file;
	std::vector< std::vector<double> > output_sets;
	std::vector<int> v;
	std::vector<double> output_vector;
	std::string str;
	int x = 0;
	double output = NAN;
	bool sorted = false;


	validate_arguments(argc,argv);
	input_file.open(argv[1]);

	while(input_file >> x){
		std::getline(input_file,str);//clear line
		v.push_back(x);
	}

	input_file.close();
	sorted = std::is_sorted(v.begin(),v.end(),MAYOR);

	switch(func){
		case 0: output = maximo(v,sorted);
				break;
		case 1: output = media(v);
				break;
		case 2: output = mediana(v,sorted);
				break;
		case 3: output_vector = moda(v,sorted);
				break;
		case 4: output_sets = permutaciones(v);
				break;
		case 5: output = desviacion(v);
				break;
		case 6: output_sets = variaciones(v);
				break;
		case 7: output_sets = variaciones_duplicados(v);
				break;
		default: exit(1);
	}

	if(!std::isnan(output))
		output_vector.push_back(output);

	if(output_vector.size())
		output_sets.push_back(output_vector);

	output_file.open("resultados.txt", std::ios::trunc | std::ios::out);

	for(auto each : output_sets){
		for(auto each2 : each){
			output_file << each2 << " ";
		}
		output_file << std::endl;
	}

	output_file.close();

	return 0;
}