#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm> //para usar std::sort -> O(nlogn)


double maximo(std::vector<int> & v, bool sorted = false){ //O(n) peor caso, O(1) caso ordenado, caso promedio es uno u otro dependiendo si esta ordenado el vector
	double max = 0;
	size_t i = 0;
	if(sorted)
		return v[0];

	for(i = 0, max = v[0]; i < v.size(); i++){
		if(max < v[i])
			max = v[i];
	}

	return max;
}

double media(std::vector<int> & v){//O(n) como peor caso, mejor caso y caso promedio
	double aux = 0;
	for(size_t i = 0; i < v.size(); i++){
		aux += v[i];
	}
	return aux /= v.size();
}//espacial O(n)

void printPowerSetResult(std::vector<std::vector<int>> vector) {
    std::cout << "[ ";
    for (const auto &eachSubset : vector){
        std::cout << "[";
        for (auto eachValue : eachSubset)
            std::cout << " " << eachValue;
        std::cout << " ]";
    }
    std::cout << " ]";
}

double mediana(std::vector<int> & v,bool sorted = false ){//O(nlogn) peor caso, O(1) mejor caso, caso promedio depende de lo que tarda sort que segun std es O(nlogn)
	double aux = 0;
	size_t mid = v.size() / 2;

	if(!sorted)
		sort(v.begin(),v.end());
	if(v.size() % 2)
		aux = v[mid];

	else aux = (double) (v[mid] + v[mid-1])/2;

	return aux;
}//espacial O(n)

double desviacion(std::vector<int> & v){//O(n) para todos los casos
	double aux = 0;
	double med = media(v);

	for(size_t i = 0; i < v.size(); i++){
		aux += pow((v[i] - med), 2);
	}
	aux = sqrt(aux/(v.size()-1));

	return aux;
}//espacial O(n)


std::vector<double> moda(std::vector<int> & v,bool sorted = false){//O(nlogn) peor caso, O(n) mejor caso, caso promedio depende de lo que tarda sort que segun std es O(nlogn)
    std::vector<double> output;
    double previous = NAN;

    if(!sorted)
    	sort(v.begin(), v.end());

    for(size_t i = 0, count = 0, count_max = 0; i < v.size() ; i++){

        if(previous != v[i]){
            count = 1;
        } else {
            count++;
        }

        if (count > count_max){
            output.clear();
            output.push_back(v[i]);
            count_max = count;
        }
        else if (count == count_max){
            output.push_back(v[i]);
        }
        previous = v[i];
    }

    if(output.size() == v.size())
        output.clear();
    
    return output;
}//espacial O(n)

void _variaciones(std::vector<int> & v,const size_t & indice, std::vector<double> * set, std::vector< std::vector<double> > * result){
    if(indice == v.size())
    	return;

    result->push_back(*set);
    
    for(size_t i = indice + 1 ; i < v.size(); i++){
    	set->push_back(v[i]);
    	_variaciones(v,i,set,result);
    	if(set->size())
    		set->erase(set->end()-1);
    }
    return;
}

std::vector< std::vector<double> > variaciones(std::vector<int> & v){
    std::vector< std::vector<double> > * result = new std::vector< std::vector<double> >;
    std::vector<double> * aux = new std::vector<double>;

    _variaciones(v,-1,aux,result);
 	return *result;
}

std::vector< std::vector<double> > permutaciones(std::vector<int> & v){
	std::vector< std::vector<double> > output;
    std::vector<double> set;
    size_t n = v.size();

    if(v.size() > 8)//para mas de 8 elementos tarda mucho
    	n = 4;

	sort(v.begin(),v.end());//O(nlogn)

	do{//O(n!)
		for(size_t i = 0; i < n; i++)//O(n)
			set.push_back(v[i]);

		output.push_back(set);
		set.clear();
	}
	while( std::next_permutation(v.begin(), v.end()) );

	return output; //O(n!)
}//espacial O(n)

std::vector< std::vector<double> > variaciones_duplicados(std::vector<int> & v){
	std::vector< std::vector<double> > output;
    std::vector<double> set;
    size_t n = v.size();
	size_t i = 0;    
    
    if(v.size() > 8)//para mas de 8 elementos tarda mucho
    	n = 4;

	sort(v.begin(),v.end());

	for(size_t j = n; j != 0; j--){//O(n-1)
		do{		
			for(i = 0; i < j; i++)
				set.push_back(v[i]);
			if (j == 1)
				std::next_permutation(v.begin(),v.end());
			output.push_back(set);
			set.clear();
		}
		while ( std::next_permutation(v.begin(),v.end()) );//O(n!)
	}

	output.push_back(set);
	
	return output;//O(n!) * O (n) = O(n*n!)
}//espacial O(n)
